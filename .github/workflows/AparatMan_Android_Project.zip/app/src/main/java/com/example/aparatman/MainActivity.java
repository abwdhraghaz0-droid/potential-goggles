package com.example.aparatman;

import android.app.Activity;
import android.os.Bundle;
import android.content.Intent;
import android.net.Uri;
import android.graphics.Color;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.*;
import android.database.Cursor;
import android.provider.OpenableColumns;
import java.util.ArrayList;

public class MainActivity extends Activity {
    private final int bg = Color.rgb(15,15,18), panel = Color.rgb(30,30,35), gold = Color.rgb(232,185,75);
    private LinearLayout root, content;
    private final ArrayList<VideoItem> videos = new ArrayList<>();
    private VideoView player;
    private static final int PICK_VIDEO = 41;

    static class VideoItem {
        Uri uri; String name;
        VideoItem(Uri u, String n) { uri=u; name=n; }
    }

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        showHome();
    }

    private TextView label(String text, int size, int color) {
        TextView t = new TextView(this); t.setText(text); t.setTextSize(size); t.setTextColor(color);
        t.setGravity(Gravity.CENTER_VERTICAL); t.setPadding(14,10,14,10); return t;
    }
    private Button button(String text, Runnable action) {
        Button b = new Button(this); b.setText(text); b.setTextColor(Color.BLACK);
        b.setBackgroundTintList(android.content.res.ColorStateList.valueOf(gold));
        b.setOnClickListener(v -> action.run()); return b;
    }
    private void base(String subtitle) {
        root = new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.setBackgroundColor(bg);
        setContentView(root);
        TextView title = label("#آپارات_من", 25, gold); title.setGravity(Gravity.CENTER); title.setPadding(10,20,10,4);
        root.addView(title, new LinearLayout.LayoutParams(-1,-2));
        TextView sub = label(subtitle, 13, Color.LTGRAY); sub.setGravity(Gravity.CENTER);
        root.addView(sub, new LinearLayout.LayoutParams(-1,-2));
        HorizontalScrollView navScroll = new HorizontalScrollView(this);
        LinearLayout nav = new LinearLayout(this); nav.setOrientation(LinearLayout.HORIZONTAL);
        nav.addView(button("خانه", this::showHome));
        nav.addView(button("کتابخانه", this::showLibrary));
        nav.addView(button("جست‌وجو", this::showSearch));
        navScroll.addView(nav); root.addView(navScroll);
        ScrollView scroll = new ScrollView(this);
        content = new LinearLayout(this); content.setPadding(14,14,14,20); content.setOrientation(LinearLayout.VERTICAL);
        scroll.addView(content); root.addView(scroll, new LinearLayout.LayoutParams(-1,0,1));
    }
    private void showHome() {
        base("کتابخانه شخصی و پخش آفلاین");
        TextView intro = label("ویدیوهای ذخیره‌شده را بدون اینترنت تماشا کنید. برای افزودن ویدیو، فایل ویدیویی را از حافظه گوشی انتخاب کنید.", 16, Color.WHITE);
        content.addView(intro);
        content.addView(button("＋ افزودن ویدیو از گوشی", this::pickVideo));
        content.addView(button("ورود به وب‌سایت آپارات", () -> openUrl("https://www.aparat.com/")));
        content.addView(button("جست‌وجوی عمومی در آپارات", () -> openUrl("https://www.aparat.com/search?search=")));
        TextView warning = label("توجه: این نسخه اولیه ورود امن از طریق وب‌سایت را باز می‌کند؛ هنوز اتصال خودکار به فهرست خصوصی حساب و دریافت مستقیم ویدیوها پیاده‌سازی نشده است.", 14, gold);
        content.addView(warning);
        content.addView(label("تعداد ویدیوهای این کتابخانه: " + videos.size(), 15, Color.WHITE));
    }
    private void showSearch() {
        base("جست‌وجوی ویدیو");
        EditText q = new EditText(this); q.setSingleLine(true); q.setHint("عنوان یا کلمه کلیدی"); q.setTextColor(Color.WHITE); q.setHintTextColor(Color.GRAY);
        content.addView(q);
        content.addView(button("جست‌وجو در آپارات", () -> {
            String query = q.getText().toString().trim();
            if(query.isEmpty()) { Toast.makeText(this,"عبارت جست‌وجو را وارد کنید",Toast.LENGTH_SHORT).show(); return; }
            openUrl("https://www.aparat.com/search?search=" + Uri.encode(query));
        }));
        content.addView(label("نتایج در وب‌سایت آپارات نمایش داده می‌شوند. برای ذخیره آفلاین، از فایل‌هایی استفاده کنید که دانلودشان مجاز است.", 14, Color.LTGRAY));
        content.addView(button("افزودن فایل دانلودشده به کتابخانه", this::pickVideo));
    }
    private void showLibrary() {
        base("کتابخانه آفلاین");
        if(videos.isEmpty()) content.addView(label("هنوز ویدیویی اضافه نشده است. از دکمه افزودن ویدیو استفاده کنید.",16,Color.LTGRAY));
        for (int i=0;i<videos.size();i++) {
            final VideoItem item = videos.get(i);
            LinearLayout card = new LinearLayout(this); card.setOrientation(LinearLayout.VERTICAL); card.setBackgroundColor(panel);
            TextView name = label("▶  " + item.name,16,Color.WHITE); card.addView(name);
            LinearLayout actions = new LinearLayout(this);
            actions.addView(button("پخش", () -> play(item.uri)));
            actions.addView(button("حذف", () -> { videos.remove(item); showLibrary(); }));
            card.addView(actions);
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1,-2); lp.setMargins(0,0,0,12); content.addView(card,lp);
        }
        if(player != null) { content.addView(label("پخش‌کننده",15,gold)); content.addView(player,new LinearLayout.LayoutParams(-1,500)); }
        content.addView(button("＋ افزودن ویدیو", this::pickVideo));
    }
    private void pickVideo() {
        Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        intent.addCategory(Intent.CATEGORY_OPENABLE); intent.setType("video/*");
        intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION);
        startActivityForResult(intent,PICK_VIDEO);
    }
    @Override protected void onActivityResult(int requestCode,int resultCode,Intent data) {
        super.onActivityResult(requestCode,resultCode,data);
        if(requestCode==PICK_VIDEO && resultCode==RESULT_OK && data!=null && data.getData()!=null) {
            Uri uri=data.getData();
            try { getContentResolver().takePersistableUriPermission(uri,Intent.FLAG_GRANT_READ_URI_PERMISSION); } catch(Exception ignored) {}
            String name="ویدیو";
            Cursor c=getContentResolver().query(uri,null,null,null,null);
            if(c!=null) { try { int ix=c.getColumnIndex(OpenableColumns.DISPLAY_NAME); if(c.moveToFirst() && ix>=0) name=c.getString(ix); } finally { c.close(); } }
            videos.add(new VideoItem(uri,name));
            showLibrary();
        }
    }
    private void play(Uri uri) {
        base("پخش آفلاین");
        player = new VideoView(this); player.setVideoURI(uri);
        MediaController controls = new MediaController(this); controls.setAnchorView(player); player.setMediaController(controls);
        content.addView(player,new LinearLayout.LayoutParams(-1,500));
        player.setOnPreparedListener(mp -> player.start());
        content.addView(label("اگر فایل روی گوشی موجود باشد، پخش بدون اینترنت انجام می‌شود.",14,Color.LTGRAY));
    }
    private void openUrl(String url) {
        try { startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(url))); }
        catch(Exception e) { Toast.makeText(this,"مرورگر در دسترس نیست",Toast.LENGTH_SHORT).show(); }
    }
}
